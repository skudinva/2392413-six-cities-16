export const getRatingPercent = (rating: number): number =>
  Math.round(rating * 20);
